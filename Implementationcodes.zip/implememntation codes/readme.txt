# Preliminary guidelines towards the implementation of ILL-ILLUMINATION ENHANCEMENT FOR IN-THE-WILD MULTIVIEW BACKLITIMAGES WITH UNKNOWN EXPOSURE AND GEOMETRY. Rizwan Khan,Qiong Liu,You Yang

#Extract and copy all codes in the laerning base restoration. 
#Apply Geometric transformation
#Implement the feature extraction SIFT techniques. 
#Start restoration process based on the techniques guided in paper
#Construct HDR from the restored Multiview LDR Images